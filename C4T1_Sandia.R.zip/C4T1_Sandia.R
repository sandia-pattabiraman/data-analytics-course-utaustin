#installing packages
install.packages("RMariaDB")
install.packages("chron")
install.packages("dplyr")
install.packages("lubridate")

#libraries
library(RMariaDB)
library(chron)
library(dplyr)
library(lubridate)

#create a database connection 
con = dbConnect(MariaDB(), user='deepAnalytics', password='Sqltask1234!',
                dbname='dataanalytics2018', host='data-analytics-2018.cbrosir2cswx.us-east-1.rds.amazonaws.com')

# List the tables contained in the database 
dbListTables(con)

# Lists attributes contained in a table
dbListFields(con,'yr_2006')
dbListFields(con,'yr_2007')
dbListFields(con,'yr_2008')
dbListFields(con,'yr_2009')
dbListFields(con,'yr_2010')

# Use asterisk to specify all attributes for download
yr_2006 <- dbGetQuery(con, "SELECT * FROM yr_2006")
yr_2007 <- dbGetQuery(con, "SELECT * FROM yr_2007")
yr_2008 <- dbGetQuery(con, "SELECT * FROM yr_2008")
yr_2009 <- dbGetQuery(con, "SELECT * FROM yr_2009")
yr_2010 <- dbGetQuery(con, "SELECT * FROM yr_2010")


# Use attribute names to specify specific attributes for download
yr_2006 <- dbGetQuery(con, "SELECT id, Date, Time, Global_active_power, global_reactive_power, 
                         Global_intensity, Voltage, Sub_metering_1, Sub_metering_2, Sub_metering_3 FROM yr_2006")
yr_2007 <- dbGetQuery(con, "SELECT id, Date, Time, Global_active_power, global_reactive_power, 
                         Global_intensity, Voltage, Sub_metering_1, Sub_metering_2, Sub_metering_3 FROM yr_2007")
yr_2008 <- dbGetQuery(con, "SELECT id, Date, Time, Global_active_power, global_reactive_power, 
                         Global_intensity, Voltage, Sub_metering_1, Sub_metering_2, Sub_metering_3 FROM yr_2008")
yr_2009 <- dbGetQuery(con, "SELECT id, Date, Time, Global_active_power, global_reactive_power, 
                         Global_intensity, Voltage, Sub_metering_1, Sub_metering_2, Sub_metering_3 FROM yr_2009")
yr_2010 <- dbGetQuery(con, "SELECT id, Date, Time, Global_active_power, global_reactive_power, 
                         Global_intensity, Voltage, Sub_metering_1, Sub_metering_2, Sub_metering_3 FROM yr_2010")

#Use str(), summary(), head() and tail() with each data frame
str(yr_2006)
summary(yr_2006)
head(yr_2006)
tail(yr_2006)

str(yr_2007)
summary(yr_2007)
head(yr_2007)
tail(yr_2007)

str(yr_2008)
summary(yr_2008)
head(yr_2008)
tail(yr_2008)

str(yr_2009)
summary(yr_2009)
head(yr_2009)
tail(yr_2009)

str(yr_2010)
summary(yr_2010)
head(yr_2010)
tail(yr_2010)

#Create your Primary Data Frame
## Combine tables into one data frame using dplyr
from2006to2010 <- bind_rows(yr_2006, yr_2007, yr_2008, yr_2009, yr_2010)
from2006to2010
#Use str(), summary(), head() and tail() with combined tables in one data frame
str(from2006to2010)
summary(from2006to2010)
head(from2006to2010)
tail(from2006to2010)

## Combine Date and Time attribute values in a new attribute column
from2006to2010 <-cbind(from2006to2010,paste(from2006to2010$Date,from2006to2010$Time), stringsAsFactors=FALSE)

#missing data 
sum(is.na (from2006to2010$id)) 
sum(is.na (from2006to2010$Date)) 
sum(is.na (from2006to2010$Time)) 
sum(is.na (from2006to2010$Global_active_power)) 
sum(is.na (from2006to2010$Global_reactive_power)) 
sum(is.na (from2006to2010$Global_intensity)) 
sum(is.na (from2006to2010$Voltage)) 
sum(is.na (from2006to2010$Sub_metering_1)) 
sum(is.na (from2006to2010$Sub_metering_2)) 
sum(is.na (from2006to2010$Sub_metering_3)) 

#duplicates 
duplicated(from2006to2010)
nrow(from2006to2010)
from2006to2010<-unique(from2006to2010)
nrow(from2006to2010)

## Give the new attribute in the 6th column a header name 
## NOTE: if you downloaded more than 5 attributes you will need to change the column number)
colnames(from2006to2010)[6] <-"DateTime"

## Move the DateTime attribute within the dataset
from2006to2010 <- from2006to2010[,c(ncol(from2006to2010), 1:(ncol(from2006to2010)-1))]
head(from2006to2010)

## Convert DateTime from character to POSIXct 
from2006to2010$DateTime <- as.POSIXct(from2006to2010$DateTime, "%Y/%m/%d %H:%M:%S", origin='France')

## Add the time zone
attr(from2006to2010$DateTime, "tzone") <- "Europe/Paris"

## Inspect the data types
str(from2006to2010)

## Create "year" attribute with lubridate
from2006to2010$year <- year(from2006to2010$DateTime)

from2006to2010

#find the percentile

quantile(yr_2010$Sub_metering_1, probs =  c(.93, .97, .99))
quantile(yr_2010$Sub_metering_2, probs =  c(.66, .97, .99))
quantile(yr_2010$Sub_metering_3, probs =  c(.24, .97, .99))


