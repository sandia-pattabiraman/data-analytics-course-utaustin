#installing packages
install.packages("arules")
install.packages("arulesViz")

#libraries
library(arules)
library(arulesViz)

#load the dataset
ElectronidexTransactions<- read.transactions("/Users/ajayvembu/Sandia_R_Projects/C3_T4/ElectronidexTransactions2017/ElectronidexTransactions2017.csv", 
                                             sep=",",rm.duplicates=TRUE)
# view the transactions
inspect (ElectronidexTransactions[0:10])

# Number of transactions
length (ElectronidexTransactions)

# Number of items per transaction
size (ElectronidexTransactions)

# Lists the transactions by conversion
options(max.print=1000000)
LIST(ElectronidexTransactions)

# To see the item labels
itemLabels(ElectronidexTransactions)

#top 20 items
itemFrequencyPlot(ElectronidexTransactions,type ="absolute",topN=20)

# No of Transactions you'd like to plot
image(ElectronidexTransactions)
sample(ElectronidexTransactions) 
image(sample(ElectronidexTransactions, 10))

#transaction from 100 to 125 
itemFrequencyPlot(ElectronidexTransactions[, 100:125], 
                  population = ElectronidexTransactions[, 100:125])
#transaction from 1 to 25 
itemFrequencyPlot(ElectronidexTransactions[, 1:25], 
                  population = ElectronidexTransactions[, 1:25])

#apriori() function 
ElectronidexTransactionsRules<- apriori (ElectronidexTransactions, parameter = list(supp = 0.001, conf = 0.5))

#max limit 
options(max.print=1000000)

#To view the rules
inspect(ElectronidexTransactionsRules)
summary(ElectronidexTransactionsRules)

#length of rules dataset 
length(ElectronidexTransactionsRules)

#top 10 support 
top.support <- sort(ElectronidexTransactionsRules, decreasing = TRUE, na.last = NA, by = "support")
inspect(top.support[1:10])

#sort the top 10 support and confidence 
inspect(sort( ElectronidexTransactionsRules, by = "support")[1:10])
inspect(sort( ElectronidexTransactionsRules, by = "confidence")[1:10])
sort(ElectronidexTransactionsRules)

#subset function using items 
inspect(subset(ElectronidexTransactionsRules, items %in% "Alienware Laptop")[1:10])
inspect(subset(ElectronidexTransactionsRules, items %in% "ViewSonic Monitor")[1:10])
inspect(subset(ElectronidexTransactionsRules, items %in% "CYBERPOWER Gamer Desktop")[1:10])
length(subset(ElectronidexTransactionsRules, items %in% "HP Laptop"))

#check redundant 
is.redundant(ElectronidexTransactionsRules)
subset.matrix <- is.subset(ElectronidexTransactionsRules, ElectronidexTransactionsRules)
subset.matrix[lower.tri(subset.matrix, diag=T)]<- NA
redundant <- colSums(subset.matrix, na.rm=T) >= 1
which(redundant)
rules.pruned <- ElectronidexTransactionsRules[!redundant]
inspect(rules.pruned)
length(rules.pruned)

#plot the rules 
plot(ElectronidexTransactionsRules[1:10], method ="graph", control=list(type="items")) 

# Top 10 Rules by higher value Support

ElectronidexTransactionsRulesTop10.support<- apriori (ElectronidexTransactions, parameter = list(supp = 0.001, conf = 0))
length(ElectronidexTransactionsRulesTop10.support)
top.ten.support <- sort(ElectronidexTransactionsRulesTop10.support, decreasing = TRUE, na.last = NA, by = "support")
inspect(top.ten.support[1:10])

# Top 10 Rules by higher value Confidence

ElectronidexTransactionsRulesTop10.confidence<- apriori (ElectronidexTransactions, parameter = list(supp = 0.001, conf = 0.9))
length(ElectronidexTransactionsRulesTop10.confidence)
top.ten.confidence <- sort(ElectronidexTransactionsRulesTop10.confidence, decreasing = TRUE, na.last = NA, by = "confidence")
inspect(top.ten.confidence[1:1])

# Top 10 Rules by 0.5 Support 

ElectronidexTransactionsRules<- apriori (ElectronidexTransactions, parameter = list(supp = 0.001, conf = 0.1))
length(ElectronidexTransactionsRules)
top.ten.support0.2 <- sort(ElectronidexTransactionsRules, decreasing = TRUE, na.last = NA, by = "support")
inspect(top.ten.support0.2[1:10])

# Top 10 Rules by 0.5 Confidence

ElectronidexTransactionsRules<- apriori (ElectronidexTransactions, parameter = list(supp = 0.001, conf = 0.5))
length(ElectronidexTransactionsRules)
top.ten.confidence0.4 <- sort(ElectronidexTransactionsRules, decreasing = TRUE, na.last = NA, by = "confidence")
inspect(top.ten.confidence0.4[1:10])

# Top 10 Rules by 0.4 Support 

ElectronidexTransactionsRules<- apriori (ElectronidexTransactions, parameter = list(supp = 0.001, conf = 0.4))
length(ElectronidexTransactionsRules)
top.ten.support0.4 <- sort(ElectronidexTransactionsRules, decreasing = TRUE, na.last = NA, by = "support")
inspect(top.ten.support0.4[2:11])

# Top 10 Rules by 0.4 Confidence

ElectronidexTransactionsRules<- apriori (ElectronidexTransactions, parameter = list(supp = 0.001, conf = 0.4))
length(ElectronidexTransactionsRules)
top.ten.confidence0.4 <- sort(ElectronidexTransactionsRules, decreasing = TRUE, na.last = NA, by = "confidence")
inspect(top.ten.confidence0.4[1:10])

# Top 10 Rules by 0.4 Support 
ElectronidexTransactionsRules<- apriori (ElectronidexTransactions, parameter = list(supp = 0.001, conf = 0.2))
length(ElectronidexTransactionsRules)
top.ten.support0.2 <- sort(ElectronidexTransactionsRules, decreasing = TRUE, na.last = NA, by = "support")
inspect(top.ten.support0.2[1:10])

# Top 10 Rules by 0.5 Support 
ElectronidexTransactionsRules<- apriori (ElectronidexTransactions, parameter = list(supp = 0.001, conf = 0.3))
length(ElectronidexTransactionsRules)
top.ten.support0.3 <- sort(ElectronidexTransactionsRules, decreasing = TRUE, na.last = NA, by = "support")
inspect(top.ten.support0.3[2:11])

# Top 10 Rules by 0.6 Support 
ElectronidexTransactionsRules<- apriori (ElectronidexTransactions, parameter = list(supp = 0.001, conf = 0.6))
length(ElectronidexTransactionsRules)
top.ten.support0.6 <- sort(ElectronidexTransactionsRules, decreasing = TRUE, na.last = NA, by = "support")
inspect(top.ten.support0.6[1:10])

# Top 10 Rules by 0.7 Support 
ElectronidexTransactionsRules<- apriori (ElectronidexTransactions, parameter = list(supp = 0.001, conf = 0.7))
length(ElectronidexTransactionsRules)
top.ten.support0.7 <- sort(ElectronidexTransactionsRules, decreasing = TRUE, na.last = NA, by = "support")
inspect(top.ten.support0.7[1:10])

# Top 10 Rules by 0.8 Support 
ElectronidexTransactionsRules<- apriori (ElectronidexTransactions, parameter = list(supp = 0.001, conf = 0.8))
length(ElectronidexTransactionsRules)
top.ten.support0.8 <- sort(ElectronidexTransactionsRules, decreasing = TRUE, na.last = NA, by = "support")
inspect(top.ten.support0.8[2:11])

# 0.1 support
ElectronidexTransactionsRules<- apriori (ElectronidexTransactions, parameter = list(supp = 0.1, conf = 0.1))
length(ElectronidexTransactionsRules)
support0.1 <- sort(ElectronidexTransactionsRules, decreasing = TRUE, na.last = NA, by = "support")
inspect(support0.1)

# 0.1 confidence
ElectronidexTransactionsRules<- apriori (ElectronidexTransactions, parameter = list(supp = 0.1, conf = 0.1))
length(ElectronidexTransactionsRules)
confidence0.1 <- sort(ElectronidexTransactionsRules, decreasing = TRUE, na.last = NA, by = "confidence")
inspect(confidence0.1)

#top 10 support 
ElectronidexTransactionsRules<- apriori (ElectronidexTransactions, parameter = list(supp = 0.001, conf = 0.4))
length(ElectronidexTransactionsRules)
last10.support <- sort(ElectronidexTransactionsRules, decreasing = FALSE, na.last = NA, by = "support")
inspect(last10.support[1:10])

                 
                 
                 