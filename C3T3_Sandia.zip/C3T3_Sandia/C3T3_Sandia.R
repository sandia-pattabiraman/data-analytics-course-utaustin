#installing pacakages
install.packages("corrplot")

#libraries
library(caret)
library(randomForest)
library(corrplot)
library(gbm)
library(e1071)
library(dplyr)

# Load  Dataset
ExistingProductOriginal<- read.csv("/Users/ajayvembu/Downloads/productattributes/existingproductattributes2017.csv")
NewProductOriginal<- read.csv("/Users/ajayvembu/Downloads/productattributes/newproductattributes2017.csv")


# dummify the existing data
newDataFrame <- dummyVars(" ~ .", data = ExistingProductOriginal)
ExistingProductOriginal <- data.frame(predict(newDataFrame, newdata = ExistingProductOriginal))
# dummify the New Product data                   
newDataFrame <- dummyVars(" ~ .", data = NewProductOriginal)
NewProductOriginal <- data.frame(predict(newDataFrame, newdata = NewProductOriginal))

#measure the correlation between the variables 
str(ExistingProductOriginal)
str(NewProductOriginal)


#to check for missing data
summary(ExistingProductOriginal) 
summary(NewProductOriginal) 

#now let's delete any attribute that has missing information. 
ExistingProductOriginal$BestSellersRank <- NULL                      
summary(ExistingProductOriginal)   

NewProductOriginal$BestSellersRank <- NULL                      
summary(NewProductOriginal)  

#Use the cor() function to build the correlation matrix:
corrData <- cor(ExistingProductOriginal)
corrplot(corrData)

corrData <- cor(NewProductOriginal)
corrplot(corrData)

#data splitting
#set the seed
set.seed(100)
trainIndex <- createDataPartition(ExistingProductOriginal$Volume, p = 0.8, list = FALSE)
training <- ExistingProductOriginal[trainIndex,]
nrow(training)
testing <- ExistingProductOriginal[-trainIndex,]
nrow(testing)

#Linear Regression Model 
set.seed(100)
linearregression <- train(Volume~., 
                          data = training, 
                          method = "lm")
linearregression

#Random forest
#rfnaive model training
# Set up a 10-fold cross validation
rfcontrol<- trainControl(method = "cv", number = 3)
set.seed(100)
rfnaivemodel1 <- train(Volume~., 
                 data = training,
                 method = "rf",
                trControl = rfcontrol) 
rfnaivemodel1

rfcontrol<- trainControl(method = "cv", number = 4)
set.seed(100)
rfnaivemodel2 <- train(Volume~., 
                      data = training,
                      method = "rf",
                      trControl = rfcontrol) 
rfnaivemodel2

rfcontrol<- trainControl(method = "cv", number = 10)
set.seed(100)
rfnaivemodel3 <- train(Volume~., 
                      data = training ,
                      method = "rf",
                      trControl = rfcontrol) 
rfnaivemodel3

#Predict rfnaive Model for Existibng Product Data Set 
#pred_naive_randomForest1 is the best model for Random forest Naive
#cv=3
pred_naive_randomForest1 <- predict(rfnaivemodel1, testing)
pred_naive_randomForest1
postResample(pred_naive_randomForest1, testing$Volume)

#cv=4
pred_naive_randomForest2 <- predict(rfnaivemodel2, testing)
pred_naive_randomForest2
postResample(pred_naive_randomForest2, testing$Volume)

#cv=10
pred_naive_randomForest3 <- predict(rfnaivemodel3, testing)
pred_naive_randomForest3
postResample(pred_naive_randomForest3, testing$Volume)


#Predict rfnaive Model for New Product Data Set 
pred_naive_randomForest2_New <- predict(rfnaivemodel2, NewProductOriginal)
pred_naive_randomForest2_New
postResample(pred_naive_randomForest2_New, NewProductOriginal$Volume)



#rfTune Grid Model with mtry you might want to test 2, 4, 6, 8, 10 in which case you would use:

#rf tune grid training
rfTuneGrid <- data.frame(mtry = seq(1, 100, by =1))
rfcontrol<- trainControl(method = "cv", number = 3)
set.seed(100)
rfTuneGridModel1 <- train(Volume~.,
                          data = training, 
                          method = "rf", 
                          tuneGrid = rfTuneGrid,
                          trControl = rfcontrol)
rfTuneGridModel1

rfcontrol<- trainControl(method = "cv", number = 4)
set.seed(100)
rfTuneGridModel2 <- train(Volume~.,
                         data = training, 
                         method = "rf", 
                         tuneGrid = rfTuneGrid,
                         trControl = rfcontrol)
rfTuneGridModel2

rfcontrol<- trainControl(method = "cv", number = 10)
set.seed(100)
rfTuneGridModel3 <- train(Volume~.,
                         data = training, 
                         method = "rf", 
                         tuneGrid = rfTuneGrid,
                         trControl = rfcontrol)
rfTuneGridModel3


#rfTune Grid model prediction 
#pred_TuneGrid_randomForest2 is the best model for Random forest Tune Grid 
#cv=3
pred_TuneGrid_randomForest1 <- predict(rfTuneGridModel1, testing)
pred_TuneGrid_randomForest1
postResample(pred_TuneGrid_randomForest1, testing$Volume)

#cv=4
pred_TuneGrid_randomForest2 <- predict(rfTuneGridModel2, testing)
pred_TuneGrid_randomForest2
postResample(pred_TuneGrid_randomForest2, testing$Volume)

#cv=10
pred_TuneGrid_randomForest3 <- predict(rfTuneGridModel3, testing)
pred_TuneGrid_randomForest3
postResample(pred_TuneGrid_randomForest3, testing$Volume)

#Predict rTuneGrid Model for New Product Data Set 
pred_TuneGrid_randomForest1_New <- predict(rfTuneGridModel1, NewProductOriginal)
pred_TuneGrid_randomForest1_New
postResample(pred_TuneGrid_randomForest1_New, NewProductOriginal$Volume)

# rf tune length training 
rfcontrol<- trainControl(method = "cv", number = 3)
set.seed(100)
rfTuneLengthModel1 <- train(Volume ~ . , 
                           data=training,
                           method='rf', 
                           tuneLength=26, 
                           trControl=rfcontrol,
                           ntree=1000)
rfTuneLengthModel1

rfcontrol<- trainControl(method = "cv", number = 4)
set.seed(100)
rfTuneLengthModel2 <- train(Volume ~ . , 
                           data=training,
                           method='rf', 
                           tuneLength=26, 
                           trControl=rfcontrol,
                           ntree=1000)
rfTuneLengthModel2

rfcontrol<- trainControl(method = "cv", number = 10)
set.seed(100)
rfTuneLengthModel3 <- train(Volume ~ . , 
                           data=training,
                           method='rf', 
                           tuneLength=26, 
                           trControl=rfcontrol,
                           ntree=1000)
rfTuneLengthModel3

#rfTune Length model prediction 
#pred_TuneGrid_randomForest1 is the best model for Random forest Tune Length
#cv=3
pred_TuneLength_randomForest1 <- predict(rfTuneLengthModel1, testing)
pred_TuneLength_randomForest1
postResample(pred_TuneLength_randomForest1, testing$Volume)

#cv=4
pred_TuneLength_randomForest2 <- predict(rfTuneLengthModel2, testing)
pred_TuneLength_randomForest2
postResample(pred_TuneLength_randomForest2, testing$Volume)

#cv=10
pred_TuneLength_randomForest3 <- predict(rfTuneLengthModel3, testing)
pred_TuneLength_randomForest3
postResample(pred_TuneLength_randomForest3, testing$Volume)

#Predict rfTune Length Model for New Product Data Set - Here TunelengthModel has the best RMSE,R-Squared and MAE Values
pred_TuneLength_randomForest1_New <- predict(rfTuneLengthModel1, NewProductOriginal)
pred_TuneLength_randomForest1_New
postResample(pred_TuneLength_randomForest1_New, NewProductOriginal$Volume)




# SVM Naive Non Linear Training
svm_train_control <- trainControl(method="repeatedcv", number=3, repeats=10)
set.seed(100)
svmRadialNaiveModel<- train(Volume ~ ., 
                            data = training, 
                            method = "svmRadial", 
                            trControl = svm_train_control)

svmRadialNaiveModel

# SVM Tune Grid Non Linear Training
set.seed(100)
SVMTuneGrid <- expand.grid(C=c(0.01,0.05,0.1), degree=c(1,2), scale=c(0.25,0.5,1))
svmTuneGridRadialModel <- train(Volume ~., 
                                data = training, 
                                method = "svmRadial", 
                                trControl = svm_train_control, 
                                preProcess = c("center","scale"), 
                                tunegrid = SVMTuneGrid,
                                gamma=1)
svmTuneGridRadialModel

# SVM Tune Length Non Linear  Training
set.seed(100)
svmTuneLengthRadialModel <- train(Volume ~.,
                                  data = training, 
                                  method = "svmRadial", 
                                  trControl = svm_train_control, 
                                  preProcess = c("center","scale"),
                                  tuneLength = 100,
                                  gamma=1)

svmTuneLengthRadialModel

#SVM Naive  Non Linear prediction 
#pred_Naive_SVM is the best model for SVM  Naive
#cv=3
pred_NaiveRadial_SVM <- predict(svmRadialNaiveModel, testing)
pred_NaiveRadial_SVM
postResample(pred_NaiveRadial_SVM, testing$Volume)

#SVM Tune Grid Non Linear prediction 
#pred_TuneGrid_SVM is the best model for SVM  Tune Grid
#cv=3
pred_TuneGridRadial_SVM <- predict(svmTuneGridRadialModel, testing)
pred_TuneGridRadial_SVM
postResample(pred_TuneGridRadial_SVM, testing$Volume)

#SVM Tune Length Non Linear prediction 
#pred_TuneLength_SVM is the best model for SVM  Tune Length
#cv=3
pred_TuneLengthRadial_SVM <- predict(svmTuneLengthRadialModel, testing)
pred_TuneLengthRadial_SVM
postResample(pred_TuneLengthRadial_SVM, testing$Volume)

#Predict SVM Tune Grid Non Linear Model for New Product Data Set - Here Naive, Tune Grid and Tune length have the same R-Squared,RMSE and MAE values.
pred_TuneLengthRadial_SVM_New <- predict(svmTuneLengthRadialModel, NewProductOriginal)
pred_TuneLengthRadial_SVM_New
postResample(pred_TuneLengthRadial_SVM_New, testing$Volume)




# Gradient Boosting Regression Model 
gbmControl <- trainControl(method = "repeatedcv",number = 3,repeats = 10)

#GBM Naive Training  
set.seed(100)
gbmNaiveModel <- train(Volume ~ ., 
                         data = training, 
                         method = "gbm", 
                         trControl = gbmControl,
                         verbose = FALSE)
gbmNaiveModel

# GBM Tune Grid Training 
gbmTuneGrid <- expand.grid(shrinkage = seq(0.1, 1, by = 0.2), 
                          interaction.depth = c(1, 3, 7, 10),
                          n.minobsinnode = c(2, 5, 10),
                          n.trees = c(100, 300, 500, 1000))
set.seed(100)
gbmTuneGridModel <- train(Volume ~ ., 
                          data = training, 
                          method = "gbm", 
                          tuneGrid = gbmTuneGrid,
                          trControl = gbmControl, 
                          verbose = FALSE)
gbmTuneGridModel
nrow(gbmTuneGridModel$results)

# GBM Tune Length Training
set.seed(100)
gbmTuneLengthModel <- train(Volume ~ .,
                            data = training, 
                            method = "gbm", 
                            tuneLength = 200,
                            trControl = gbmControl, 
                            verbose = FALSE)
gbmTuneLengthModel


#GBM Naive model prediction 
#pred_Naive_GBM is the best model for GBM Naive
#cv=3
pred_Naive_GBM <- predict(gbmNaiveModel, testing)
pred_Naive_GBM
postResample(pred_Naive_GBM, testing$Volume)

#GBM Tune Grid model prediction 
#pred_Tune_Grid_GBM is the best model for GBM Tune Grid
#cv=3
pred_TuneGrid_GBM <- predict(gbmTuneGridModel, testing)
pred_TuneGrid_GBM
postResample(pred_TuneGrid_GBM, testing$Volume)

#GBM Tune Length model prediction 
#pred_Tune_Length_GBM is the best model for GBM Tune Length
#cv=3
pred_TuneLength_GBM <- predict(gbmTuneLengthModel, testing)
pred_TuneLength_GBM
postResample(pred_TuneLength_GBM, testing$Volume)

#Predict GBM Tune Grid Model for New Product Data Set - Here Naive model has  the best RMSE,R-Squared and MAE Values.
pred_TuneGrid_GBM_New <- predict(gbmTuneGridModel, NewProductOriginal)
pred_TuneGrid_GBM_New
postResample(pred_TuneGrid_GBM_New, testing$Volume)




# Add Column to NewProductOriginal-
NewProductOriginal$pred_TuneLength_randomForest1_New <- pred_TuneLength_randomForest1_New
# Add Column to New Product_original-
NewProductOriginal$pred_TuneLengthRadial_SVM_New <- pred_TuneLengthRadial_SVM_New
# Add Column to NewProductOriginal-
NewProductOriginal$pred_TuneGrid_GBM_New <- pred_TuneGrid_GBM_New

#Removed Columns
NewProductOriginal <- subset (NewProductOriginal, select = -c(ProductTypeAccessories,ProductTypeDisplay,ProductTypeExtendedWarranty, 
                                                              ProductTypeGameConsole,ProductTypePrinter,ProductTypePrinterSupplies,
                                                              ProductTypeSoftware,ProductTypeTablet))
#Filtering the columns 
NewProductOriginal <- filter(NewProductOriginal, ProductTypeLaptop == 1 | ProductTypePC == 1 | ProductTypeNetbook == 1 | ProductTypeSmartphone == 1)

NewProductOriginal[, c(1,2,3,4,20,21,22)]

write.csv(NewProductOriginal, file="/Users/ajayvembu/Downloads/productattributes/newproductPredicted.csv",row.names = TRUE)




