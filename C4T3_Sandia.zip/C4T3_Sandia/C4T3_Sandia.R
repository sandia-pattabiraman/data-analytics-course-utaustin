#installing packages
install.packages("caret")
install.packages("dplyr")
install.packages("ggplot2")
install.packages("tidyverse")
install.packages("stringr")

#libraries
library(caret)
library(dplyr)
library(ggplot2)
library(tidyverse)
library(stringr)


## Import Dataset
Wifi_TrainingData  <- read.csv("/Users/ajayvembu/Downloads/UJIndoorLoc/trainingData.csv")
str(Wifi_TrainingData)
attributes(Wifi_TrainingData)

# create working data set
Wifi_TD <- Wifi_TrainingData 

## Subset to focus on building 2 and floor 2 TD
# Wifi <- filter(TD, FLOOR == 2 & BUILDINGID == 2)
## Subset to focus on building 2 
Wifi_TD <- filter(Wifi_TD, BUILDINGID == 2)

## Create by combining BUILDINGID,FLOOR,Space ID and Relative Position ID into one attribute called FSR_ID
Wifi_TD <- within(Wifi_TD, FSR_ID <- paste( FLOOR, SPACEID, RELATIVEPOSITION, sep= '_'))
Wifi_TD

## FSR_ID needs to be change to factor to make this a classification problem. 
Wifi_TD$FSR_ID <- as.factor(Wifi_TD$FSR_ID)
str(Wifi_TD$FSR_ID)
attributes(Wifi_TD$FSR_ID)
str(Wifi_TD)

## Remove attributes that we won't be using (LONGITUD, LATITUDE, TIMESTAMP, PHONEID, USERID, FLOOR, BUILDINGID,SPACEID,RELATIVEPOSITIONID)
Wifi_TD$LONGITUDE <- as.null(Wifi_TD$LONGITUDE)
Wifi_TD$LATITUDE <- as.null(Wifi_TD$LATITUDE)
Wifi_TD$TIMESTAMP <- as.null(Wifi_TD$TIMESTAMP)
Wifi_TD$PHONEID <- as.null(Wifi_TD$PHONEID)
Wifi_TD$USERID <- as.null(Wifi_TD$USERID)
Wifi_TD$FLOOR <- as.null(Wifi_TD$FLOOR)
Wifi_TD$BUILDINGID <- as.null(Wifi_TD$BUILDINGID)
Wifi_TD$SPACEID <- as.null(Wifi_TD$SPACEID)
Wifi_TD$RELATIVEPOSITION <- as.null(Wifi_TD$RELATIVEPOSITION)

# NearZeroVar Test and Removal of Zero Var Predictors
nzv <- nearZeroVar(Wifi_TD, saveMetrics= TRUE)
head(nzv)
summary(nzv) # table: attributes can be removed for ZERO Variance 

zeroVarData1 <- which(nzv$zeroVar == T)
zeroVarData1 # list of Zero Var Predicters

# remove each observation from the list 
WIFI_TDset <- Wifi_TD[,-(zeroVarData1)] 

# check dependant 
str(WIFI_TDset$FSR_ID) 

# check number of features and obs 
str(WIFI_TDset)

## Create Training and Testing 
set.seed(123)
inTraining <- createDataPartition(WIFI_TDset$FSR_ID, p = .70, list = FALSE)
training <- WIFI_TDset[inTraining, ]
testing <- WIFI_TDset[-inTraining, ]

# Check dependant to be sure number of factor levels matches in test and train
str(testing$FSR_ID) 
str(training$FSR_ID) 


## RFCross Validation
RFcontrol <- trainControl(method = "repeatedcv", number = 10, repeats = 1 )
## Modeling Random Forest
RFModel <- train(FSR_ID~., data = training, 
                 method = "rf", 
                 trControl = RFcontrol)
RFModel
ggplot(RFModel)
saveRDS(RFModel, "/Users/ajayvembu/Sandia_R_Projects/C4T3/RFModel.rds")

## Prediction on test set with RFModel 
testPredRF <- predict(RFModel, testing)
## Post Resample
post <- postResample(testPredRF, testing$FSR_ID)
post
## Confusion Matrix
cmRF <- confusionMatrix(testPredRF, testing$FSR_ID)
## 
str(testPredRF)
RFtocsv <-data.frame(cbind(t(cmRF$byClass)))
# You can then use
write.csv(RFtocsv,file="/Users/ajayvembu/Sandia_R_Projects/C4T3/RFConfusionMatrix.csv")


## C5.0 Cross Validation
C5.0control <- trainControl(method = "repeatedcv", number = 10, repeats = 1 )
## Modeling C5.0
C5.0Model <- train(FSR_ID~., data = training, 
                   method = "C5.0", 
                   trControl = C5.0control)
C5.0Model
ggplot(C5.0Model)
saveRDS(C5.0Model, "/Users/ajayvembu/Sandia_R_Projects/C4T3/C5.0Model.rds")



## Prediction on test set with C5.0Model
testPredC5.0 <- predict(C5.0Model, testing)
## Post Resample
post <- postResample(testPredC5.0, testing$FSR_ID)
post
## Confusion Matrix
cmC5.0 <-confusionMatrix(testPredC5.0, testing$FSR_ID)
## 
str(testPredC5.0)

C5.0tocsv <- data.frame(cbind(t(cmC5.0$byClass)))
# You can then use
write.csv(C5.0tocsv,file="/Users/ajayvembu/Sandia_R_Projects/C4T3/C5.0ConfusionMatrix.csv")



## KNNCross Validation
KNNcontrol <- trainControl(method = "repeatedcv", number = 10, repeats = 1 )
## Modeling KNN
KNNModel <- train(FSR_ID~., data = training, 
                  method = "knn", 
                  trControl = KNNcontrol)
KNNModel
ggplot(KNNModel)
saveRDS(KNNModel, "/Users/ajayvembu/Sandia_R_Projects/C4T3/KNNModel.rds")

## Prediction on test set with KNNModel 
testPredKNN <- predict(KNNModel, testing)
## Post Resample
post <- postResample(testPredKNN, testing$FSR_ID)
post
## Confusion Matrix
cmKNN <- confusionMatrix(testPredKNN, testing$FSR_ID)
## 
str(testPredKNN)
KNNtocsv <- data.frame(cbind(t(cmKNN$byClass)))
# You can then use
write.csv(KNNtocsv,file="/Users/ajayvembu/Sandia_R_Projects/C4T3/KNNConfusionMatrix.csv")



#FinalModeldata
ModelData <- resamples(list(RandomForest = RFModel, C50 = C5.0Model, KNN = KNNModel ))
s <- summary(ModelData)
capture.output(s, file = "/Users/ajayvembu/Sandia_R_Projects/C4T3/ModelData.txt")
ModelData
ggplot(ModelData)










