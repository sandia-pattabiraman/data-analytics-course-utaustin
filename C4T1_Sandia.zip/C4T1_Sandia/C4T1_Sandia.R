#installing packages
install.packages("RMariaDB")
install.packages("chron")
install.packages("dplyr")
install.packages("lubridate")

#libraries
library(RMariaDB)
library(chron)
library(dplyr)
library(lubridate)

#create a database connection 
con = dbConnect(MariaDB(), user='deepAnalytics', password='Sqltask1234!',
                dbname='dataanalytics2018', host='data-analytics-2018.cbrosir2cswx.us-east-1.rds.amazonaws.com')

# List the tables contained in the database 
dbListTables(con)

# Lists attributes contained in a table
dbListFields(con,'yr_2006')
dbListFields(con,'yr_2007')
dbListFields(con,'yr_2008')
dbListFields(con,'yr_2009')
dbListFields(con,'yr_2010')


# Use attribute names to specify specific attributes for download
yr_2007 <- dbGetQuery(con, "SELECT Date, Time, Sub_metering_1, Sub_metering_2, Sub_metering_3 FROM yr_2007")
yr_2008 <- dbGetQuery(con, "SELECT Date, Time, Sub_metering_1, Sub_metering_2, Sub_metering_3 FROM yr_2008")
yr_2009 <- dbGetQuery(con, "SELECT Date, Time, Sub_metering_1, Sub_metering_2, Sub_metering_3 FROM yr_2009")

#Use str(), summary(), head() and tail() with each data frame
str(yr_2007)
summary(yr_2007)
head(yr_2007)
tail(yr_2007)

str(yr_2008)
summary(yr_2008)
head(yr_2008)
tail(yr_2008)

str(yr_2009)
summary(yr_2009)
head(yr_2009)
tail(yr_2009)

#Create your Primary Data Frame
## Combine tables into one data frame using dplyr
from2007to2009 <- bind_rows( yr_2007, yr_2008, yr_2009)
from2007to2009

#Use str(), summary(), head() and tail() with combined tables in one data frame
str(from2007to2009)
summary(from2007to2009)
head(from2007to2009)
tail(from2007to2009)

## Combine Date and Time attribute values in a new attribute column
from2007to2009 <-cbind(from2007to2009,paste(from2007to2009$Date,from2007to2009$Time), stringsAsFactors=FALSE)

#missing data 
sum(is.na (from2007to2009$id)) 
sum(is.na (from2007to2009$Date)) 
sum(is.na (from2007to2009$Time)) 
sum(is.na (from2007to2009$Global_active_power)) 
sum(is.na (from2007to2009$Global_reactive_power)) 
sum(is.na (from2007to2009$Global_intensity)) 
sum(is.na (from2007to2009$Voltage)) 
sum(is.na (from2007to2009$Sub_metering_1)) 
sum(is.na (from2007to2009$Sub_metering_2)) 
sum(is.na (from2007to2009$Sub_metering_3)) 

#duplicates 
duplicated(from2007to2009)
nrow(from2007to2009)
from2007to2009<-unique(from2007to2009)
nrow(from2007to2009)

## Give the new attribute in the 6th column a header name 
## NOTE: if you downloaded more than 5 attributes you will need to change the column number)
colnames(from2007to2009)[6] <-"DateTime"

## Move the DateTime attribute within the dataset
from2007to2009 <- from2007to2009[,c(ncol(from2007to2009), 1:(ncol(from2007to2009)-1))]
head(from2007to2009)

## Convert DateTime from character to POSIXct 
from2007to2009$DateTime <- as.POSIXct(from2007to2009$DateTime, "%Y/%m/%d %H:%M:%S")

## Add the time zone
attr(from2007to2009$DateTime, "tzone") <- "Europe/London"

## Inspect the data types
str(from2007to2009)

## Create "year" attribute with lubridate
from2007to2009$year <- year(from2007to2009$DateTime)
from2007to2009

## Create "month" attribute with lubridate
from2007to2009$month <- month(from2007to2009$DateTime)
from2007to2009

## Create "quarter" attribute with lubridate
from2007to2009$quarter <- quarter(from2007to2009$DateTime)
from2007to2009

## Create "week" attribute with lubridate
from2007to2009$week <- week(from2007to2009$DateTime)
from2007to2009

## Create "day" attribute with lubridate
from2007to2009$day <- day(from2007to2009$DateTime)
from2007to2009

## Create "hour" attribute with lubridate
from2007to2009$hour <- hour(from2007to2009$DateTime)
from2007to2009

## Create "minute" attribute with lubridate
from2007to2009$minute <- minute(from2007to2009$DateTime)
from2007to2009

#find the percentile
quantile(from2007to2009$Sub_metering_1, probs =  c(.92, .97, .99))
quantile(from2007to2009$Sub_metering_2, probs =  c(.72, .97, .99))
quantile(from2007to2009$Sub_metering_3, probs =  c(.47, .97, .99))


