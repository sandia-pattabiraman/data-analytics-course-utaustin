#installing packages
install.packages("RMariaDB")
install.packages("chron")
install.packages("dplyr")
install.packages("lubridate")
install.packages("plotly")
install.packages("ggplot2")
install.packages("ggfortify")
install.packages("tidyverse")
install.packages("forecast")

#libraries
library(RMariaDB)
library(chron)
library(dplyr)
library(lubridate)
library(plotly)
library(ggplot2)
library(ggfortify)
library(tidyverse)
library(forecast)



#create a database connection 
con = dbConnect(MariaDB(), user='deepAnalytics', password='Sqltask1234!',
                dbname='dataanalytics2018', host='data-analytics-2018.cbrosir2cswx.us-east-1.rds.amazonaws.com')


# List the tables contained in the database 
dbListTables(con)

# Lists attributes contained in a table
dbListFields(con,'yr_2006')
dbListFields(con,'yr_2007')
dbListFields(con,'yr_2008')
dbListFields(con,'yr_2009')
dbListFields(con,'yr_2010')


# Use attribute names to specify specific attributes for download
yr_2007 <- dbGetQuery(con, "SELECT Date, Time, Sub_metering_1, Sub_metering_2, Sub_metering_3 FROM yr_2007")
yr_2008 <- dbGetQuery(con, "SELECT Date, Time, Sub_metering_1, Sub_metering_2, Sub_metering_3 FROM yr_2008")
yr_2009 <- dbGetQuery(con, "SELECT Date, Time, Sub_metering_1, Sub_metering_2, Sub_metering_3 FROM yr_2009")

#Use str(), summary(), head() and tail() with each data frame
str(yr_2007)
summary(yr_2007)
head(yr_2007)
tail(yr_2007)

str(yr_2008)
summary(yr_2008)
head(yr_2008)
tail(yr_2008)

str(yr_2009)
summary(yr_2009)
head(yr_2009)
tail(yr_2009)

#Create your Primary Data Frame
## Combine tables into one data frame using dplyr
from2007to2009 <- bind_rows( yr_2007, yr_2008, yr_2009)
from2007to2009

#Use str(), summary(), head() and tail() with combined tables in one data frame
str(from2007to2009)
summary(from2007to2009)
head(from2007to2009)
tail(from2007to2009)

## Combine Date and Time attribute values in a new attribute column
from2007to2009 <-cbind(from2007to2009,paste(from2007to2009$Date,from2007to2009$Time), stringsAsFactors=FALSE)


#missing data 
sum(is.na (from2007to2009$id)) 
sum(is.na (from2007to2009$Date)) 
sum(is.na (from2007to2009$Time)) 
sum(is.na (from2007to2009$Global_active_power)) 
sum(is.na (from2007to2009$Global_reactive_power)) 
sum(is.na (from2007to2009$Global_intensity)) 
sum(is.na (from2007to2009$Voltage)) 
sum(is.na (from2007to2009$Sub_metering_1)) 
sum(is.na (from2007to2009$Sub_metering_2)) 
sum(is.na (from2007to2009$Sub_metering_3)) 

#duplicates 
duplicated(from2007to2009)
nrow(from2007to2009)
from2007to2009<-unique(from2007to2009)
nrow(from2007to2009)

## Give the new attribute in the 6th column a header name 
## NOTE: if you downloaded more than 5 attributes you will need to change the column number)
colnames(from2007to2009)[6] <-"DateTime"

## Move the DateTime attribute within the dataset
from2007to2009 <- from2007to2009[,c(ncol(from2007to2009), 1:(ncol(from2007to2009)-1))]
head(from2007to2009)

## Convert DateTime from character to POSIXct 
from2007to2009$DateTime <- as.POSIXct(from2007to2009$DateTime, "%Y/%m/%d %H:%M:%S")

## Add the time zone
attr(from2007to2009$DateTime, "tzone") <- "Europe/London"

## Inspect the data types
str(from2007to2009)

## Create "year" attribute with lubridate
from2007to2009$year <- year(from2007to2009$DateTime)
from2007to2009

## Create "month" attribute with lubridate
from2007to2009$month <- month(from2007to2009$DateTime)
from2007to2009

## Create "quarter" attribute with lubridate
from2007to2009$quarter <- quarters(from2007to2009$DateTime)
from2007to2009

## Create "week" attribute with lubridate
from2007to2009$week <- week(from2007to2009$DateTime)
from2007to2009

## Create "day" attribute with lubridate
from2007to2009$day <- day(from2007to2009$DateTime)
from2007to2009

## Create "week day" attribute with lubridate
from2007to2009$weekday <- weekdays(from2007to2009$DateTime)
from2007to2009

## Create "hour" attribute with lubridate
from2007to2009$hour <- hour(from2007to2009$DateTime)
from2007to2009

## Create "minute" attribute with lubridate
from2007to2009$minute <- minute(from2007to2009$DateTime)
from2007to2009

#find the percentile
quantile(from2007to2009$Sub_metering_1, probs =  c(.92, .97, .99))
quantile(from2007to2009$Sub_metering_2, probs =  c(.72, .97, .99))
quantile(from2007to2009$Sub_metering_3, probs =  c(.47, .97, .99))

# Write the Current Data to file
write.csv(from2007to2009,"/Users/ajayvembu/Sandia_R_Projects/C4T2/from2007to2009_all_variables.csv")


# -------------------- Start from here --------------------------------------------------------------------------------------
from2007to2009 <- read.csv("/Users/ajayvembu/Sandia_R_Projects/C4T2/from2007to2009_all_variables.csv")

## Plot all of sub-meter 1,2,3
plot(from2007to2009$Sub_metering_1)
from2007to2009
plot(from2007to2009$Sub_metering_2)
from2007to2009
plot(from2007to2009$Sub_metering_3)
from2007to2009

## Subset the first week of 2007- All Observations
houseWeek_07_1 <- filter(from2007to2009, year == 2007 & week == 1)
## Subset the second week of 2007 - All Observations
houseWeek_07_26 <- filter(from2007to2009, year == 2007 & week == 26)
## Subset the third week of 2007 - All Observations
houseWeek_07_52 <- filter(from2007to2009, year == 2007 & week == 52)

## Plot subset houseWeek for 2007
plot(houseWeek_07_1$Sub_metering_1)
plot(houseWeek_07_1$Sub_metering_2)
plot(houseWeek_07_1$Sub_metering_3)

plot(houseWeek_07_26$Sub_metering_1)
plot(houseWeek_07_26$Sub_metering_2)
plot(houseWeek_07_26$Sub_metering_3)

plot(houseWeek_07_52$Sub_metering_1)
plot(houseWeek_07_52$Sub_metering_2)
plot(houseWeek_07_52$Sub_metering_3)

## Plot sub-meter 1, 2 and 3 with title, legend and labels - All observations 
#Power Consumption January 9th, 2007
plot_ly(houseWeek_07_1, x = ~houseWeek_07_1$DateTime, 
        y = ~houseWeek_07_1$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseWeek_07_1$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseWeek_07_1$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption 1st week, 2007",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

## Plot sub-meter 1, 2 and 3 with title, legend and labels - All observations 
#Power Consumption June 12th, 2007
plot_ly(houseWeek_07_26, x = ~houseWeek_07_26$DateTime, 
        y = ~houseWeek_07_26$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseWeek_07_26$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseWeek_07_26$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption 26th week, 2007",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

#Power Consumption December 25th, 2007
plot_ly(houseWeek_07_52, x = ~houseWeek_07_52$DateTime, 
        y = ~houseWeek_07_52$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseWeek_07_52$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseWeek_07_52$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption 52nd week, 2007",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

## Subset the first week of 2008- All Observations
houseWeek_08_1 <- filter(from2007to2009, year == 2008 & week == 1)
## Subset the second week of 2008 - All Observations
houseWeek_08_26 <- filter(from2007to2009, year == 2008 & week == 26)
## Subset the third week of 2008 - All Observations
houseWeek_08_52 <- filter(from2007to2009, year == 2008 & week == 52)

## Plot subset houseWeek for 2007
plot(houseWeek_08_1$Sub_metering_1)
plot(houseWeek_08_1$Sub_metering_2)
plot(houseWeek_08_1$Sub_metering_3)

plot(houseWeek_08_26$Sub_metering_1)
plot(houseWeek_08_26$Sub_metering_2)
plot(houseWeek_08_26$Sub_metering_3)

plot(houseWeek_08_52$Sub_metering_1)
plot(houseWeek_08_52$Sub_metering_2)
plot(houseWeek_08_52$Sub_metering_3)

## Plot sub-meter 1, 2 and 3 with title, legend and labels - All observations 
#Power Consumption January 9th, 2007
plot_ly(houseWeek_08_1, x = ~houseWeek_08_1$DateTime, 
        y = ~houseWeek_08_1$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseWeek_08_1$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseWeek_08_1$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption 1st week, 2008",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

## Plot sub-meter 1, 2 and 3 with title, legend and labels - All observations 
#Power Consumption June 12th, 2007
plot_ly(houseWeek_08_26, x = ~houseWeek_08_26$DateTime, 
        y = ~houseWeek_08_26$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseWeek_08_26$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseWeek_08_26$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption 26th week, 2008",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

#Power Consumption December 25th, 2007
plot_ly(houseWeek_08_52, x = ~houseWeek_08_52$DateTime, 
        y = ~houseWeek_08_52$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseWeek_08_52$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseWeek_08_52$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption 52nd week, 2008",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

## Subset the first week of 2009- All Observations
houseWeek_09_1 <- filter(from2007to2009, year == 2009 & week == 1)
## Subset the second week of 2009 - All Observations
houseWeek_09_26 <- filter(from2007to2009, year == 2009 & week == 26)
## Subset the third week of 2009 - All Observations
houseWeek_09_52 <- filter(from2007to2009, year == 2009 & week == 52)

## Plot subset houseWeek for 2007
plot(houseWeek_09_1$Sub_metering_1)
plot(houseWeek_09_1$Sub_metering_2)
plot(houseWeek_09_1$Sub_metering_3)

plot(houseWeek_09_26$Sub_metering_1)
plot(houseWeek_09_26$Sub_metering_2)
plot(houseWeek_09_26$Sub_metering_3)

plot(houseWeek_09_52$Sub_metering_1)
plot(houseWeek_09_52$Sub_metering_2)
plot(houseWeek_09_52$Sub_metering_3)

## Plot sub-meter 1, 2 and 3 with title, legend and labels - All observations 
#Power Consumption January 9th, 2007
plot_ly(houseWeek_09_1, x = ~houseWeek_09_1$DateTime, 
        y = ~houseWeek_09_1$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseWeek_09_1$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseWeek_09_1$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption 1st week, 2009",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

## Plot sub-meter 1, 2 and 3 with title, legend and labels - All observations 
#Power Consumption June 12th, 2007
plot_ly(houseWeek_09_26, x = ~houseWeek_09_26$DateTime, 
        y = ~houseWeek_09_26$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseWeek_09_26$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseWeek_09_26$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption 26th week, 2009",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

#Power Consumption December 25th, 2007
plot_ly(houseWeek_09_52, x = ~houseWeek_09_52$DateTime, 
        y = ~houseWeek_09_52$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseWeek_09_52$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseWeek_09_52$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption 52nd week, 2009",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

##-----------------------------------------------------------------------------------------------------------------------------------------------------

## Subset the 9th day of January 2007 - All observations
houseDay1_07 <- filter(from2007to2009, year == 2007 & month == 1 & day == 9)
houseDay2_07 <- filter(from2007to2009, year == 2007 & month == 6 & day == 12)
houseDay3_07 <- filter(from2007to2009, year == 2007 & month == 12 & day == 25)
nrow(houseDay1)

## Plot sub-meter 1,2,3
plot_ly(houseDay1_07, x = ~houseDay1_07$DateTime, y = ~houseDay1_07$Sub_metering_1, type = 'scatter', mode = 'lines')
plot_ly(houseDay1_07, x = ~houseDay1_07$DateTime, y = ~houseDay1_07$Sub_metering_2, type = 'scatter', mode = 'lines')
plot_ly(houseDay1_07, x = ~houseDay1_07$DateTime, y = ~houseDay1_07$Sub_metering_3, type = 'scatter', mode = 'lines')

plot_ly(houseDay2_07, x = ~houseDay2_07$DateTime, y = ~houseDay2_07$Sub_metering_1, type = 'scatter', mode = 'lines')
plot_ly(houseDay2_07, x = ~houseDay2_07$DateTime, y = ~houseDay2_07$Sub_metering_2, type = 'scatter', mode = 'lines')
plot_ly(houseDay2_07, x = ~houseDay2_07$DateTime, y = ~houseDay2_07$Sub_metering_3, type = 'scatter', mode = 'lines')

plot_ly(houseDay3_07, x = ~houseDay3_07$DateTime, y = ~houseDay3_07$Sub_metering_1, type = 'scatter', mode = 'lines')
plot_ly(houseDay3_07, x = ~houseDay3_07$DateTime, y = ~houseDay3_07$Sub_metering_2, type = 'scatter', mode = 'lines')
plot_ly(houseDay3_07, x = ~houseDay3_07$DateTime, y = ~houseDay3_07$Sub_metering_3, type = 'scatter', mode = 'lines')

## Plot sub-meter 1, 2 and 3 with title, legend and labels - All observations 
#Power Consumption January 9th, 2007
plot_ly(houseDay1_07, x = ~houseDay1_07$DateTime, 
        y = ~houseDay1_07$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay1_07$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay1_07$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption January 9th, 2007",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

## Plot sub-meter 1, 2 and 3 with title, legend and labels - All observations 
#Power Consumption June 12th, 2007
plot_ly(houseDay2_07, x = ~houseDay2_07$DateTime, 
        y = ~houseDay2_07$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay2_07$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay2_07$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption June 12th, 2007",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

#Power Consumption December 25th, 2007
plot_ly(houseDay3_07, x = ~houseDay3_07$DateTime, 
        y = ~houseDay3_07$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay3_07$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay3_07$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption December 25th, 2007",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))


## Subset the 10th day of February 2008 - All observations
houseDay1_08 <- filter(from2007to2009, year == 2008 & month == 1 & day == 9)
houseDay2_08 <- filter(from2007to2009, year == 2008 & month == 6 & day == 12)
houseDay3_08 <- filter(from2007to2009, year == 2008 & month == 12 & day == 25)

## Plot sub-meter 1,2,3
plot_ly(houseDay1_08, x = ~houseDay1_08$DateTime, y = ~houseDay1_08$Sub_metering_1, type = 'scatter', mode = 'lines')
plot_ly(houseDay1_08, x = ~houseDay1_08$DateTime, y = ~houseDay1_08$Sub_metering_2, type = 'scatter', mode = 'lines')
plot_ly(houseDay1_08, x = ~houseDay1_08$DateTime, y = ~houseDay1_08$Sub_metering_3, type = 'scatter', mode = 'lines')

plot_ly(houseDay2_08, x = ~houseDay1_08$DateTime, y = ~houseDay1_08$Sub_metering_1, type = 'scatter', mode = 'lines')
plot_ly(houseDay2_08, x = ~houseDay1_08$DateTime, y = ~houseDay1_08$Sub_metering_2, type = 'scatter', mode = 'lines')
plot_ly(houseDay2_08, x = ~houseDay1_08$DateTime, y = ~houseDay1_08$Sub_metering_3, type = 'scatter', mode = 'lines')

plot_ly(houseDay3_08, x = ~houseDay1_08$DateTime, y = ~houseDay1_08$Sub_metering_1, type = 'scatter', mode = 'lines')
plot_ly(houseDay3_08, x = ~houseDay1_08$DateTime, y = ~houseDay1_08$Sub_metering_2, type = 'scatter', mode = 'lines')
plot_ly(houseDay3_08, x = ~houseDay1_08$DateTime, y = ~houseDay1_08$Sub_metering_3, type = 'scatter', mode = 'lines')

## Plot sub-meter 1, 2 and 3 with title, legend and labels - All observations 
#Power Consumption January 9th, 2008
plot_ly(houseDay1_08, x = ~houseDay1_08$DateTime, 
        y = ~houseDay1_08$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay1_08$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay1_08$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption January 9th, 2008",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

## Plot sub-meter 1, 2 and 3 with title, legend and labels - All observations 
#Power Consumption June 12th, 2008
plot_ly(houseDay2_08, x = ~houseDay2_08$DateTime, 
        y = ~houseDay2_08$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay2_08$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay2_08$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption June 12th, 2008",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

#Power Consumption December 25th, 2008
plot_ly(houseDay3_08, x = ~houseDay3_08$DateTime, 
        y = ~houseDay3_08$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay3_08$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay3_08$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption December 25th, 2008",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))


## Subset the 11th day of March 2009 - All observations
houseDay1_09 <- filter(from2007to2009, year == 2009 & month == 1 & day == 9)
houseDay2_09 <- filter(from2007to2009, year == 2009 & month == 6 & day == 12)
houseDay3_09 <- filter(from2007to2009, year == 2009& month == 12 & day == 25)


## Plot sub-meter 1,2,3
plot_ly(houseDay1_09, x = ~houseDay1_09$DateTime, y = ~houseDay1_09$Sub_metering_1, type = 'scatter', mode = 'lines')
plot_ly(houseDay1_09, x = ~houseDay1_09$DateTime, y = ~houseDay1_09$Sub_metering_2, type = 'scatter', mode = 'lines')
plot_ly(houseDay1_09, x = ~houseDay1_09$DateTime, y = ~houseDay1_09$Sub_metering_3, type = 'scatter', mode = 'lines')

plot_ly(houseDay2_09, x = ~houseDay2_09$DateTime, y = ~houseDay2_09$Sub_metering_1, type = 'scatter', mode = 'lines')
plot_ly(houseDay2_09, x = ~houseDay2_09$DateTime, y = ~houseDay2_09$Sub_metering_2, type = 'scatter', mode = 'lines')
plot_ly(houseDay2_09, x = ~houseDay2_09$DateTime, y = ~houseDay2_09$Sub_metering_3, type = 'scatter', mode = 'lines')

plot_ly(houseDay3_09, x = ~houseDay3_09$DateTime, y = ~houseDay3_09$Sub_metering_1, type = 'scatter', mode = 'lines')
plot_ly(houseDay3_09, x = ~houseDay3_09$DateTime, y = ~houseDay3_09$Sub_metering_2, type = 'scatter', mode = 'lines')
plot_ly(houseDay3_09, x = ~houseDay3_09$DateTime, y = ~houseDay3_09$Sub_metering_3, type = 'scatter', mode = 'lines')

#Power Consumption January 9th, 2009
plot_ly(houseDay1_09, x = ~houseDay1_09$DateTime, 
        y = ~houseDay1_09$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay1_09$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay1_09$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption January 9th, 2009",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))


#Power Consumption June 12th, 2009
plot_ly(houseDay2_09, x = ~houseDay2_09$DateTime, 
        y = ~houseDay2_09$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay2_09$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay2_09$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption June 12th, 2009",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

#Power Consumption December 25th, 2009
plot_ly(houseDay3_09, x = ~houseDay3_09$DateTime, 
        y = ~houseDay3_09$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay3_09$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay3_09$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption December 25th, 2009",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

##-------------------------------------------------------------------------------------------------------------------------------
## Subset the 9,12,25th day of January,june,december 2008 - 10 Minute frequency
houseDay1_07 <- filter(from2007to2009, year == 2007 & month == 1 & day == 9 & 
          (minute == 0 | minute == 10 | minute == 20 | minute == 30 | minute == 40 | minute == 50 ))
houseDay2_07 <- filter(from2007to2009, year == 2007 & month == 6 & day == 12 & 
          (minute == 0 | minute == 10 | minute == 20 | minute == 30 | minute == 40 | minute == 50 ))
houseDay3_07 <- filter(from2007to2009, year == 2007 & month == 12 & day == 25 & 
          (minute == 0 | minute == 10 | minute == 20 | minute == 30 | minute == 40 | minute == 50 ))

## Plot sub-meter 1, 2 and 3 with title, legend and labels 2007- 10 Minute frequency
plot_ly(houseDay1_07, x = ~houseDay1_07$DateTime, 
        y = ~houseDay1_07$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay1_07$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay1_07$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption January 9th, 2007",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

plot_ly(houseDay2_07, x = ~houseDay2_07$DateTime, 
        y = ~houseDay2_07$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay2_07$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay2_07$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption June 12th, 2007",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

plot_ly(houseDay3_07, x = ~houseDay3_07$DateTime, 
        y = ~houseDay3_07$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay3_07$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay3_07$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption December 25th, 2007",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

## Subset the 9,12,25th day of jan,june,dec 2008 - 10 Minute frequency
houseDay1_08 <- filter(from2007to2009, year == 2008 & month == 1 & day == 9 & 
          (minute == 0 | minute == 10 | minute == 20 | minute == 30 | minute == 40 | minute == 50 ))
houseDay2_08 <- filter(from2007to2009, year == 2008 & month == 6 & day == 12 & 
          (minute == 0 | minute == 10 | minute == 20 | minute == 30 | minute == 40 | minute == 50 ))
houseDay3_08 <- filter(from2007to2009, year == 2008 & month == 12 & day == 25 & 
          (minute == 0 | minute == 10 | minute == 20 | minute == 30 | minute == 40 | minute == 50 ))

## Plot sub-meter 1, 2 and 3 with title, legend and labels 2008- 10 Minute frequency
plot_ly(houseDay1_08, x = ~houseDay1_08$DateTime, 
        y = ~houseDay1_08$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay1_08$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay1_08$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption January 9th, 2008",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

plot_ly(houseDay2_08, x = ~houseDay2_08$DateTime, 
        y = ~houseDay2_08$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay2_08$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay2_08$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption June 12th, 2008",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

plot_ly(houseDay3_08, x = ~houseDay3_08$DateTime, 
        y = ~houseDay3_08$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay3_08$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay3_08$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption December 25th, 2008",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

## Subset the 9,12,25 day of Jan,June,Dec 2009- 10 Minute frequency
houseDay1_09 <- filter(from2007to2009, year == 2009 & month == 1 & day == 9 & 
          (minute == 0 | minute == 10 | minute == 20 | minute == 30 | minute == 40 | minute == 50 ))
houseDay2_09 <- filter(from2007to2009, year == 2009 & month == 6 & day == 12 & 
          (minute == 0 | minute == 10 | minute == 20 | minute == 30 | minute == 40 | minute == 50 ))
houseDay3_09 <- filter(from2007to2009, year == 2009 & month == 12 & day == 25 & 
          (minute == 0 | minute == 10 | minute == 20 | minute == 30 | minute == 40 | minute == 50 ))

## Plot sub-meter 1, 2 and 3 with title, legend and labels 2009- 10 Minute frequency
plot_ly(houseDay1_09, x = ~houseDay1_09$DateTime, 
        y = ~houseDay1_09$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay1_09$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay1_09$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption January 9th, 2009",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

plot_ly(houseDay2_09, x = ~houseDay2_09$DateTime, 
        y = ~houseDay2_09$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay2_09$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay2_09$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption June 12th, 2009",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

plot_ly(houseDay3_09, x = ~houseDay3_09$DateTime, 
        y = ~houseDay3_09$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay3_09$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay3_09$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption December 25th, 2009",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

#---------------------------------------------------------------------------------------------------------------------
## Subset to one observation per week on Mondays at 8:00pm for 2007, 2008 and 2009
house070809weekly <- filter(from2007to2009, weekday == "Monday" & hour == 20 & minute == 1)
house070809daily<- filter(from2007to2009,  hour == 20 & minute == 1)
house070809hourly<- filter(from2007to2009,  minute == 1)

## Create TS object with SubMeter1,2,3
#For frequency- Weekly means no of weeks in one year is 52weeks
tsSM1_070809weekly <- ts(house070809weekly$Sub_metering_1, frequency=52, start=c(2007,1))
tsSM2_070809weekly <- ts(house070809weekly$Sub_metering_2, frequency=52, start=c(2007,1))
tsSM3_070809weekly <- ts(house070809weekly$Sub_metering_3, frequency=52, start=c(2007,1))

autoplot(tsSM1_070809weekly)
autoplot(tsSM2_070809weekly)
autoplot(tsSM3_070809weekly)

## Plot sub-meter 1, 2 and 3 with title, legend and labels 2009- 10 Minute frequency
plot_ly(house070809weekly, x = ~house070809weekly$DateTime, 
        y = ~house070809weekly$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~house070809weekly$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~house070809weekly$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption with weekly frequency 52",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))


#For frequency- Daily means total no of days in a year is 365 days 
tsSM1_070809daily <- ts(house070809daily$Sub_metering_1, frequency=365, start=c(2007,1)) 
tsSM2_070809daily <- ts(house070809daily$Sub_metering_2, frequency=365, start=c(2007,1)) 
tsSM3_070809daily <- ts(house070809daily$Sub_metering_3, frequency=365, start=c(2007,1)) 

autoplot(tsSM1_070809daily)
autoplot(tsSM2_070809daily)
autoplot(tsSM3_070809daily)

## Plot sub-meter 1, 2 and 3 with title, legend and labels 2009- 10 Minute frequency
plot_ly(house070809daily, x = ~house070809daily$DateTime, 
        y = ~house070809daily$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~house070809daily$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~house070809daily$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption with daily frequency 365 ",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

#For frequency- Hourly means total no of days in a year * total no of hrs  per day = 365*24=8760 hours
tsSM1_070809hourly <- ts(house070809hourly$Sub_metering_1, frequency=8760, start=c(2007,1)) 
tsSM2_070809hourly <- ts(house070809hourly$Sub_metering_2, frequency=8760, start=c(2007,1)) 
tsSM3_070809hourly <- ts(house070809hourly$Sub_metering_3, frequency=8760, start=c(2007,1)) 

autoplot(tsSM1_070809hourly)
autoplot(tsSM2_070809hourly)
autoplot(tsSM3_070809hourly)

plot_ly(house070809hourly, x = ~house070809hourly$DateTime, 
        y = ~house070809hourly$Sub_metering_1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~house070809hourly$Sub_metering_2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~house070809hourly$Sub_metering_3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption with hourly frequency 8760",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

## Plot sub-meter 1,2,3 with autoplot - add labels, color
autoplot(tsSM1_070809weekly, colour = 'red', xlab = "Time", ylab = "Watt Hours", main = "Sub-meter 1")
autoplot(tsSM2_070809weekly, colour = 'red', xlab = "Time", ylab = "Watt Hours", main = "Sub-meter 2")
autoplot(tsSM3_070809weekly, colour = 'red', xlab = "Time", ylab = "Watt Hours", main = "Sub-meter 3")

autoplot(tsSM1_070809daily, colour = 'blue', xlab = "Time", ylab = "Watt Hours", main = "Sub-meter 1")
autoplot(tsSM2_070809daily, colour = 'blue', xlab = "Time", ylab = "Watt Hours", main = "Sub-meter 2")
autoplot(tsSM3_070809daily, colour = 'blue', xlab = "Time", ylab = "Watt Hours", main = "Sub-meter 3")

autoplot(tsSM1_070809hourly, colour = 'green', xlab = "Time", ylab = "Watt Hours", main = "Sub-meter 1")
autoplot(tsSM2_070809hourly, colour = 'green', xlab = "Time", ylab = "Watt Hours", main = "Sub-meter 2")
autoplot(tsSM3_070809hourly, colour = 'green', xlab = "Time", ylab = "Watt Hours", main = "Sub-meter 3")

## Plot sub-meter 1,2,3 with plot.ts
plot.ts(tsSM1_070809weekly)
plot.ts(tsSM2_070809weekly)
plot.ts(tsSM3_070809weekly)

plot.ts(tsSM1_070809daily)
plot.ts(tsSM2_070809daily)
plot.ts(tsSM3_070809daily)

plot.ts(tsSM1_070809hourly)
plot.ts(tsSM2_070809hourly)
plot.ts(tsSM3_070809hourly)

## Apply time series linear regression to the sub-meter 1,2,3 ts object 
#and use summary to obtain R2 and RMSE from the model you built
LinearSM1_W <- tslm(tsSM1_070809weekly ~ trend + season) 
summary(LinearSM1_W)
LinearSM2_W <- tslm(tsSM2_070809weekly ~ trend + season) 
summary(LinearSM2_W)
LinearSM3_W <- tslm(tsSM3_070809weekly ~ trend + season) 
summary(LinearSM3_W)


LinearSM1_D <- tslm(tsSM1_070809daily ~ trend + season) 
summary(LinearSM1_D)
LinearSM2_D <- tslm(tsSM2_070809daily ~ trend + season) 
summary(LinearSM2_D)
LinearSM3_D <- tslm(tsSM3_070809daily ~ trend + season) 
summary(LinearSM3_D)


LinearSM1_H <- tslm(tsSM3_070809hourly ~ trend + season) 
summary(LinearSM1_H)
LinearSM2_H <- tslm(tsSM3_070809hourly ~ trend + season) 
summary(LinearSM2_H)
LinearSM3_H <- tslm(tsSM3_070809hourly ~ trend + season) 
summary(LinearSM3_H)

## Create the forecast for sub-meter 1,2,3. Forecast ahead 20 time periods 
#20 time periods is nothing but 5 months. which is 52weeks for 1 year
forecastLinearSM1_W <- forecast(LinearSM1_W, h=20)
forecastLinearSM2_W <- forecast(LinearSM2_W, h=20)
forecastLinearSM3_W <- forecast(LinearSM3_W, h=20)

#For daily time period, 5 months is equal to 150 which is 30*5 =150
forecastLinearSM1_D <- forecast(LinearSM1_D, h=150)
forecastLinearSM2_D <- forecast(LinearSM2_D, h=150)
forecastLinearSM3_D <- forecast(LinearSM3_D, h=150)

# For hour time period, 1 day is 24 hrs and 5 months is 150 ,so 150*24=3600
forecastLinearSM1_H <- forecast(LinearSM1_H, h=3600)
forecastLinearSM2_H <- forecast(LinearSM2_H, h=3600)
forecastLinearSM3_H <- forecast(LinearSM3_H, h=3600)

## Plot the forecast for sub-meter 1,2,3. 
plot(forecastLinearSM1_W)
plot(forecastLinearSM2_W)
plot(forecastLinearSM3_W)


plot(forecastLinearSM1_D)
plot(forecastLinearSM2_D)
plot(forecastLinearSM3_D)

plot(forecastLinearSM1_H)
plot(forecastLinearSM2_H)
plot(forecastLinearSM3_H)

## Create sub-meter 1,2,3 forecast with confidence levels 80 and 90
forecastLinearSM1_Wc <- forecast(LinearSM1_W, h=20, level=c(80,90))
forecastLinearSM2_Wc <- forecast(LinearSM2_W, h=20, level=c(80,90))
forecastLinearSM3_Wc <- forecast(LinearSM3_W, h=20, level=c(80,90))

forecastLinearSM1_Dc <- forecast(LinearSM1_D, h=20, level=c(85,95))
forecastLinearSM2_Dc <- forecast(LinearSM2_D, h=20, level=c(85,95))
forecastLinearSM3_Dc <- forecast(LinearSM3_D, h=20, level=c(85,95))

forecastLinearSM1_Hc <- forecast(LinearSM1_H, h=20, level=c(89,99))
forecastLinearSM2_Hc <- forecast(LinearSM2_H, h=20, level=c(89,99))
forecastLinearSM3_Hc <- forecast(LinearSM3_H, h=20, level=c(89,99))

## Plot sub-meter 1,2,3 forecast, limit y and add labels
plot(forecastLinearSM1_Wc, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time")
plot(forecastLinearSM2_Wc, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time")
plot(forecastLinearSM3_Wc, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time")

plot(forecastLinearSM1_Dc, ylim = c(1, 15), ylab= "Watt-Hours", xlab="Time")
plot(forecastLinearSM2_Dc, ylim = c(1, 15), ylab= "Watt-Hours", xlab="Time")
plot(forecastLinearSM3_Dc, ylim = c(1, 15), ylab= "Watt-Hours", xlab="Time")

plot(forecastLinearSM1_Hc, ylim = c(2, 10), ylab= "Watt-Hours", xlab="Time")
plot(forecastLinearSM2_Hc, ylim = c(2, 10), ylab= "Watt-Hours", xlab="Time")
plot(forecastLinearSM3_Hc, ylim = c(2, 10), ylab= "Watt-Hours", xlab="Time")

## Decompose Sub-meter 1,2,3 into trend, seasonal and remainder
decompose070809SM1weekly <- decompose(tsSM1_070809weekly)
decompose070809SM2weekly <- decompose(tsSM2_070809weekly)
decompose070809SM3weekly <- decompose(tsSM3_070809weekly)

decompose070809SM1daily <- decompose(tsSM2_070809daily)
decompose070809SM2daily <- decompose(tsSM2_070809daily)
decompose070809SM3daily <- decompose(tsSM3_070809daily)

decompose070809SM1hourly <- decompose(tsSM1_070809hourly)
decompose070809SM2hourly <- decompose(tsSM2_070809hourly)
decompose070809SM3hourly <- decompose(tsSM3_070809hourly)

## Plot decomposed sub-meter 1,2,3 
plot(decompose070809SM1weekly)
plot(decompose070809SM2weekly)
plot(decompose070809SM3weekly)

plot(decompose070809SM1daily)
plot(decompose070809SM2daily)
plot(decompose070809SM3daily)

plot(decompose070809SM1hourly)
plot(decompose070809SM2hourly)
plot(decompose070809SM3hourly)

## Check summary statistics for decomposed sub-meter 1,2,3 
summary(decompose070809SM1weekly)
summary(decompose070809SM2weekly)
summary(decompose070809SM3weekly)

summary(decompose070809SM1daily)
summary(decompose070809SM2daily)
summary(decompose070809SM3daily)

summary(decompose070809SM3hourly)
summary(decompose070809SM3hourly)
summary(decompose070809SM3hourly)


## Seasonal adjusting sub-meter 1,2,3 by subtracting the seasonal component & plot
tsSM1_070809_W_Adjusted <- tsSM1_070809weekly - decompose070809SM1weekly$seasonal
tsSM2_070809_W_Adjusted <- tsSM2_070809weekly - decompose070809SM2weekly$seasonal
tsSM3_070809_W_Adjusted <- tsSM3_070809weekly - decompose070809SM3weekly$seasonal

tsSM1_070809_D_Adjusted <- tsSM1_070809daily - decompose070809SM1daily$seasonal
tsSM2_070809_D_Adjusted <- tsSM2_070809daily - decompose070809SM2daily$seasonal
tsSM3_070809_D_Adjusted <- tsSM3_070809daily - decompose070809SM3daily$seasonal

tsSM1_070809_H_Adjusted <- tsSM1_070809hourly - decompose070809SM1hourly$seasonal
tsSM2_070809_H_Adjusted <- tsSM2_070809hourly - decompose070809SM2hourly$seasonal
tsSM3_070809_H_Adjusted <- tsSM3_070809hourly - decompose070809SM3hourly$seasonal

autoplot(tsSM1_070809_W_Adjusted)
autoplot(tsSM2_070809_W_Adjusted)
autoplot(tsSM3_070809_W_Adjusted)

autoplot(tsSM1_070809_D_Adjusted)
autoplot(tsSM2_070809_D_Adjusted)
autoplot(tsSM3_070809_D_Adjusted)

autoplot(tsSM1_070809_H_Adjusted)
autoplot(tsSM2_070809_H_Adjusted)
autoplot(tsSM3_070809_H_Adjusted)

## Test Seasonal Adjustment by running Decompose again. Note the very, very small scale for Seasonal
plot(decompose(tsSM1_070809_W_Adjusted))
plot(decompose(tsSM2_070809_W_Adjusted))
plot(decompose(tsSM3_070809_W_Adjusted))

plot(decompose(tsSM1_070809_D_Adjusted))
plot(decompose(tsSM2_070809_D_Adjusted))
plot(decompose(tsSM3_070809_D_Adjusted))

plot(decompose(tsSM1_070809_H_Adjusted))
plot(decompose(tsSM2_070809_H_Adjusted))
plot(decompose(tsSM3_070809_H_Adjusted))

## Holt Winters Exponential Smoothing & Plot
tsSM1_W_HW070809 <- HoltWinters(tsSM1_070809_W_Adjusted, beta=FALSE, gamma=FALSE)
tsSM2_W_HW070809 <- HoltWinters(tsSM2_070809_W_Adjusted, beta=FALSE, gamma=FALSE)
tsSM3_W_HW070809 <- HoltWinters(tsSM3_070809_W_Adjusted, beta=FALSE, gamma=FALSE)

tsSM1_D_HW070809 <- HoltWinters(tsSM1_070809_D_Adjusted, beta=FALSE, gamma=FALSE)
tsSM2_D_HW070809 <- HoltWinters(tsSM2_070809_D_Adjusted, beta=FALSE, gamma=FALSE)
tsSM3_D_HW070809 <- HoltWinters(tsSM3_070809_D_Adjusted, beta=FALSE, gamma=FALSE)

tsSM1_H_HW070809 <- HoltWinters(tsSM1_070809_H_Adjusted, beta=FALSE, gamma=FALSE)
tsSM2_H_HW070809 <- HoltWinters(tsSM2_070809_H_Adjusted, beta=FALSE, gamma=FALSE)
tsSM3_H_HW070809 <- HoltWinters(tsSM3_070809_H_Adjusted, beta=FALSE, gamma=FALSE)

plot(tsSM1_W_HW070809, ylim = c(0, 25))
plot(tsSM2_W_HW070809, ylim = c(0, 25))
plot(tsSM3_W_HW070809, ylim = c(0, 25))

plot(tsSM1_D_HW070809, ylim = c(1, 30))
plot(tsSM2_D_HW070809, ylim = c(1, 30))
plot(tsSM3_D_HW070809, ylim = c(1, 30))

plot(tsSM1_H_HW070809, ylim = c(2, 35))
plot(tsSM2_H_HW070809, ylim = c(2, 35))
plot(tsSM3_H_HW070809, ylim = c(2, 35))


## HoltWinters forecast & plot
tsSM1__W_HW070809forecast <- forecast(tsSM1_W_HW070809, h=25)
tsSM2__W_HW070809forecast <- forecast(tsSM2_W_HW070809, h=25)
tsSM3__W_HW070809forecast <- forecast(tsSM3_W_HW070809, h=25)

tsSM1_D_HW070809forecast <- forecast(tsSM2_D_HW070809, h=180)
tsSM2_D_HW070809forecast <- forecast(tsSM2_D_HW070809, h=180)
tsSM3_D_HW070809forecast <- forecast(tsSM3_D_HW070809, h=180)

tsSM1_H_HW070809forecast <- forecast(tsSM1_H_HW070809, h=4320)
tsSM2_H_HW070809forecast <- forecast(tsSM2_H_HW070809, h=4320)
tsSM3_H_HW070809forecast <- forecast(tsSM3_H_HW070809, h=4320)

plot(tsSM1__W_HW070809forecast, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time - Sub-meter 1")
plot(tsSM2__W_HW070809forecast, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time - Sub-meter 2")
plot(tsSM3__W_HW070809forecast, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time - Sub-meter 3")

plot(tsSM1_D_HW070809forecast, ylim = c(1, 15), ylab= "Watt-Hours", xlab="Time - Sub-meter 1")
plot(tsSM2_D_HW070809forecast, ylim = c(1, 15), ylab= "Watt-Hours", xlab="Time - Sub-meter 2")
plot(tsSM3_D_HW070809forecast, ylim = c(1, 15), ylab= "Watt-Hours", xlab="Time - Sub-meter 3")

plot(tsSM1_H_HW070809forecast, ylim = c(2, 10), ylab= "Watt-Hours", xlab="Time - Sub-meter 1")
plot(tsSM2_H_HW070809forecast, ylim = c(2, 10), ylab= "Watt-Hours", xlab="Time - Sub-meter 2")
plot(tsSM3_H_HW070809forecast, ylim = c(2, 10), ylab= "Watt-Hours", xlab="Time - Sub-meter 3")


## Forecast HoltWinters with diminished confidence levels
tsSM1__W_HW070809forecastC <- forecast(tsSM1_W_HW070809, h=25, level=c(10,25))
tsSM2__W_HW070809forecastC <- forecast(tsSM2_W_HW070809, h=25, level=c(10,25))
tsSM3__W_HW070809forecastC <- forecast(tsSM3_W_HW070809, h=25, level=c(10,25))

tsSM1_D_HW070809forecastC <- forecast(tsSM1_D_HW070809, h=30, level=c(20,35))
tsSM2_D_HW070809forecastC <- forecast(tsSM2_D_HW070809, h=30, level=c(20,35))
tsSM3_D_HW070809forecastC <- forecast(tsSM3_D_HW070809, h=30, level=c(20,35))

tsSM1_H_HW070809forecastC <- forecast(tsSM1_H_HW070809, h=35, level=c(30,45))
tsSM2_H_HW070809forecastC <- forecast(tsSM2_H_HW070809, h=35, level=c(30,45))
tsSM3_H_HW070809forecastC <- forecast(tsSM3_H_HW070809, h=35, level=c(30,45))

## Plot only the forecasted area
plot(tsSM1__W_HW070809forecastC, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time - Sub-meter 1", start(2010))
plot(tsSM2__W_HW070809forecastC, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time - Sub-meter 1", start(2010))
plot(tsSM3__W_HW070809forecastC, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time - Sub-meter 1", start(2010))

plot(tsSM1_D_HW070809forecastC, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time - Sub-meter 2", start(2010))
plot(tsSM2_D_HW070809forecastC, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time - Sub-meter 2", start(2010))
plot(tsSM3_D_HW070809forecastC, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time - Sub-meter 2", start(2010))

plot(tsSM1_H_HW070809forecastC, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time - Sub-meter 3", start(2010))
plot(tsSM2_H_HW070809forecastC, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time - Sub-meter 3", start(2010))
plot(tsSM3_H_HW070809forecastC, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time - Sub-meter 3", start(2010))

